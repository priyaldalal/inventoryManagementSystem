﻿namespace Inventpr
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TXTFNAME = new System.Windows.Forms.Label();
            this.USERID = new System.Windows.Forms.Label();
            this.TXTLNAME = new System.Windows.Forms.Label();
            this.TXTUSER = new System.Windows.Forms.Label();
            this.EMAIL = new System.Windows.Forms.Label();
            this.TXTPASS = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textname = new System.Windows.Forms.TextBox();
            this.textlname = new System.Windows.Forms.TextBox();
            this.textusername = new System.Windows.Forms.TextBox();
            this.textemail = new System.Windows.Forms.TextBox();
            this.textpassword = new System.Windows.Forms.TextBox();
            this.BTNSAVE = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.BACK = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // TXTFNAME
            // 
            this.TXTFNAME.AutoSize = true;
            this.TXTFNAME.Location = new System.Drawing.Point(26, 15);
            this.TXTFNAME.Name = "TXTFNAME";
            this.TXTFNAME.Size = new System.Drawing.Size(47, 13);
            this.TXTFNAME.TabIndex = 1;
            this.TXTFNAME.Text = "FNAME:";
            // 
            // USERID
            // 
            this.USERID.AutoSize = true;
            this.USERID.Location = new System.Drawing.Point(-2, 2);
            this.USERID.Name = "USERID";
            this.USERID.Size = new System.Drawing.Size(48, 13);
            this.USERID.TabIndex = 13;
            this.USERID.Text = "USERID";
            // 
            // TXTLNAME
            // 
            this.TXTLNAME.AutoSize = true;
            this.TXTLNAME.Location = new System.Drawing.Point(26, 46);
            this.TXTLNAME.Name = "TXTLNAME";
            this.TXTLNAME.Size = new System.Drawing.Size(47, 13);
            this.TXTLNAME.TabIndex = 14;
            this.TXTLNAME.Text = "LNAME:";
            // 
            // TXTUSER
            // 
            this.TXTUSER.AutoSize = true;
            this.TXTUSER.Location = new System.Drawing.Point(25, 80);
            this.TXTUSER.Name = "TXTUSER";
            this.TXTUSER.Size = new System.Drawing.Size(74, 13);
            this.TXTUSER.TabIndex = 15;
            this.TXTUSER.Text = "USER NAME:";
            // 
            // EMAIL
            // 
            this.EMAIL.AutoSize = true;
            this.EMAIL.Location = new System.Drawing.Point(25, 111);
            this.EMAIL.Name = "EMAIL";
            this.EMAIL.Size = new System.Drawing.Size(42, 13);
            this.EMAIL.TabIndex = 16;
            this.EMAIL.Text = "EMAIL:";
            // 
            // TXTPASS
            // 
            this.TXTPASS.AutoSize = true;
            this.TXTPASS.Location = new System.Drawing.Point(25, 145);
            this.TXTPASS.Name = "TXTPASS";
            this.TXTPASS.Size = new System.Drawing.Size(73, 13);
            this.TXTPASS.TabIndex = 17;
            this.TXTPASS.Text = "PASSWORD:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 183);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(523, 150);
            this.dataGridView1.TabIndex = 18;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // textname
            // 
            this.textname.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textname.Location = new System.Drawing.Point(136, 12);
            this.textname.Name = "textname";
            this.textname.Size = new System.Drawing.Size(285, 20);
            this.textname.TabIndex = 19;
            // 
            // textlname
            // 
            this.textlname.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textlname.Location = new System.Drawing.Point(136, 43);
            this.textlname.Name = "textlname";
            this.textlname.Size = new System.Drawing.Size(285, 20);
            this.textlname.TabIndex = 20;
            // 
            // textusername
            // 
            this.textusername.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textusername.Location = new System.Drawing.Point(136, 77);
            this.textusername.Name = "textusername";
            this.textusername.Size = new System.Drawing.Size(285, 20);
            this.textusername.TabIndex = 21;
            // 
            // textemail
            // 
            this.textemail.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textemail.Location = new System.Drawing.Point(136, 108);
            this.textemail.Name = "textemail";
            this.textemail.Size = new System.Drawing.Size(285, 20);
            this.textemail.TabIndex = 22;
            // 
            // textpassword
            // 
            this.textpassword.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textpassword.Location = new System.Drawing.Point(136, 145);
            this.textpassword.Name = "textpassword";
            this.textpassword.Size = new System.Drawing.Size(285, 20);
            this.textpassword.TabIndex = 23;
            // 
            // BTNSAVE
            // 
            this.BTNSAVE.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BTNSAVE.Location = new System.Drawing.Point(436, 15);
            this.BTNSAVE.Name = "BTNSAVE";
            this.BTNSAVE.Size = new System.Drawing.Size(75, 23);
            this.BTNSAVE.TabIndex = 24;
            this.BTNSAVE.Text = "SAVE";
            this.BTNSAVE.UseVisualStyleBackColor = true;
            this.BTNSAVE.Click += new System.EventHandler(this.BTNSAVE_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnupdate.Location = new System.Drawing.Point(436, 46);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(75, 23);
            this.btnupdate.TabIndex = 25;
            this.btnupdate.Text = "UPDATE";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Location = new System.Drawing.Point(436, 77);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 26;
            this.button1.Text = "Login";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.Location = new System.Drawing.Point(436, 108);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 27;
            this.button2.Text = "Refresh";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // BACK
            // 
            this.BACK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BACK.Location = new System.Drawing.Point(436, 145);
            this.BACK.Name = "BACK";
            this.BACK.Size = new System.Drawing.Size(75, 23);
            this.BACK.TabIndex = 28;
            this.BACK.Text = "BACK";
            this.BACK.UseVisualStyleBackColor = true;
            this.BACK.Click += new System.EventHandler(this.BACK_Click);
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 341);
            this.Controls.Add(this.BACK);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.BTNSAVE);
            this.Controls.Add(this.textpassword);
            this.Controls.Add(this.textemail);
            this.Controls.Add(this.textusername);
            this.Controls.Add(this.textlname);
            this.Controls.Add(this.textname);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.TXTPASS);
            this.Controls.Add(this.EMAIL);
            this.Controls.Add(this.TXTUSER);
            this.Controls.Add(this.TXTLNAME);
            this.Controls.Add(this.USERID);
            this.Controls.Add(this.TXTFNAME);
            this.Name = "Register";
            this.Text = "Register";
            this.Load += new System.EventHandler(this.Register_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label TXTFNAME;
        private System.Windows.Forms.Label USERID;
        private System.Windows.Forms.Label TXTLNAME;
        private System.Windows.Forms.Label TXTUSER;
        private System.Windows.Forms.Label EMAIL;
        private System.Windows.Forms.Label TXTPASS;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textname;
        private System.Windows.Forms.TextBox textlname;
        private System.Windows.Forms.TextBox textusername;
        private System.Windows.Forms.TextBox textemail;
        private System.Windows.Forms.TextBox textpassword;
        private System.Windows.Forms.Button BTNSAVE;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button BACK;
    }
}