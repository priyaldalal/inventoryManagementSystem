﻿using INVENT.BAL;
using INVENT.BLL;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Drawing;
using System.Collections.Generic;
using System.ComponentModel;

namespace Inventpr
{
    public partial class ProductEntry : Form
    {
        public ProductEntry()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void ProductEntry_Load(object sender, EventArgs e)
        {
            BAL_PRODUCT objBal = new BAL_PRODUCT();
            BLL_PRODUCT objBll = new BLL_PRODUCT();

            DataTable dt = objBll.GetALl(objBal);
            dataGridView1.DataSource = dt.DefaultView;

            cmdio.Items.Add("i");   // Adding values for Gender Combobox  
            cmdio.Items.Add("o");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var dataIndexNo = dataGridView1.Rows[e.RowIndex].Index.ToString();
            string cellValue = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            PID.Text = cellValue;
            PNAME.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString(); ;
            QTY.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString(); ;
            COST.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString(); ;
          
        }
        public void clearall()
        {
            PNAME.Text = "";
            QTY.Text = "";
            COST.Text = "";
            cmdio.Text = "";
          //  textpassword.Text = "";
        }
        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            var Form2 = new Form2();
            Form2.Closed += (s, args) => this.Close();
            Form2.Show();
        }

        private void save_Click(object sender, EventArgs e)
        {
            string str = "";
            BAL_PRODUCT objBal = new BAL_PRODUCT();
            BLL_PRODUCT objBll = new BLL_PRODUCT();

           
            objBal.PNAME = PNAME.Text;
            
            objBal.IOENT = cmdio.Text;
          
            objBal.QUNTITY = QTY.Text;
            objBal.COST = COST.Text;
            

            str = objBll.product(objBal);
            clearall();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string str = "";
            BAL_PRODUCT objBal = new BAL_PRODUCT();
            BLL_PRODUCT objBll = new BLL_PRODUCT();

            objBal.PNAME = PNAME.Text;

            objBal.IOENT = cmdio.Text;

            objBal.QUNTITY = QTY.Text;
            objBal.COST = COST.Text;

            str = objBll.UPDATE(objBal);
            MessageBox.Show("UPDATED");
            clearall();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            BAL_PRODUCT objBal = new BAL_PRODUCT();
            BLL_PRODUCT objBll = new BLL_PRODUCT();

            DataTable dt = objBll.GetALl(objBal);
            dataGridView1.DataSource = dt.DefaultView;
        }
    }
}
