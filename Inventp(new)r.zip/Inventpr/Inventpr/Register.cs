﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using INVENT.BAL;
using INVENT.BLL;

namespace Inventpr
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }
        public void clearall()
        {
            textname.Text = "";
            textlname.Text = "";
            textusername.Text = "";
            textemail.Text = "";
            textpassword.Text = "";
        }
        private void Register_Load(object sender, EventArgs e)
        {
            BAL_USER objBal = new BAL_USER();
            BLL_USER objBll = new BLL_USER();

            DataTable dt = objBll.GETDETAIL(objBal);
            dataGridView1.DataSource = dt.DefaultView;
        }

        private void BTNSAVE_Click(object sender, EventArgs e)
        {
            string str = "";
            BAL_USER objBal = new BAL_USER();
            BLL_USER objBll = new BLL_USER();


            objBal.FNAME = textname.Text;
            objBal.LNAME = textlname.Text;
            objBal.USERNAME = textusername.Text;
            objBal.EMAIL = textemail.Text;
            objBal.PASSWORD = textpassword.Text;


            str = objBll.ManageUser(objBal);
            MessageBox.Show("SAVE");
            clearall();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            string str = "";
            BAL_USER objBal = new BAL_USER();
            BLL_USER objBll = new BLL_USER();

            objBal.USERID = USERID.Text;
            objBal.FNAME = textname.Text;
            objBal.LNAME = textlname.Text;
            objBal.USERNAME = textusername.Text;
            objBal.EMAIL = textemail.Text;
            objBal.PASSWORD = textpassword.Text;

            str = objBll.UPDATE(objBal);
            MessageBox.Show("UPDATED");
            clearall();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var dataIndexNo = dataGridView1.Rows[e.RowIndex].Index.ToString();
            string cellValue = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            USERID.Text = cellValue;
            textname.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString(); ;
            textlname.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString(); ;
            textusername.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString(); ;
            textemail.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString(); ;
            textpassword.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString(); ;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            var Form1 = new Form1();
            Form1.Closed += (s, args) => this.Close();
            Form1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            BAL_USER objBal = new BAL_USER();
            BLL_USER objBll = new BLL_USER();

            DataTable dt = objBll.GETDETAIL(objBal);
            dataGridView1.DataSource = dt.DefaultView;
        }

        private void BACK_Click(object sender, EventArgs e)
        {
            this.Hide();
            var Form2 = new Form2();
            Form2.Closed += (s, args) => this.Close();
            Form2.Show();
        }
    }
}
