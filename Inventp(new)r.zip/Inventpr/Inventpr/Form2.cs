﻿using INVENT.BAL;
using INVENT.BLL;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Drawing;
using System.Collections.Generic;
using System.ComponentModel;

namespace Inventpr
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var dataIndexNo = dataGridView1.Rows[e.RowIndex].Index.ToString();
            string cellValue = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //fillChart2();
            BAL_PRODUCT objBal = new BAL_PRODUCT();
            BLL_PRODUCT objBll = new BLL_PRODUCT();

            DataTable dt = objBll.GetALl(objBal);
            dataGridView1.DataSource = dt.DefaultView;

        }

        private void BTNREGISTER_Click(object sender, EventArgs e)
        {
            this.Hide();
            var Register = new Register();
            Register.Closed += (s, args) => this.Close();
            Register.Show();
        }

        private void BTNCLEAR_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            var STOCK = new STOCK();
            STOCK.Closed += (s, args) => this.Close();
            STOCK.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            var Form1 = new Form1();
            Form1.Closed += (s, args) => this.Close();
            Form1.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            BAL_PRODUCT objBal = new BAL_PRODUCT();
            BLL_PRODUCT objBll = new BLL_PRODUCT();

            DataTable dt = objBll.GetALl(objBal);
            dataGridView1.DataSource = dt.DefaultView;
        }
        //private void fillChart2()
        //{
        //    SqlConnection con = new SqlConnection("Data Source=DESKTOP-C32MIJ1\\SQLEXPRESS;Initial Catalog=Inventory;User ID=sa;Password=1234;");
        //    //qlConnection con = new SqlConnection("Data Source=.;Initial Catalog=Sample;Integrated Security=true;");
        //    DataSet ds = new DataSet();
        //    con.Open();
        //    SqlDataAdapter adapt = new SqlDataAdapter("SELECT P.PID,P.PNAME,C.CNAME,B.BNAME,P.PRICE,P.QUNTITY,P.IOENT,P.DISCRIPTION, convert(varchar, P.[DATE], 105)AS [DATE]  FROM [dbo].[PRODUCT] P INNER JOIN[BRAND] B ON P.BRAND = B.BID LEFT JOIN CATEGORY C ON P.CATEGORY = C.CID ORDER BY B.BNAME, B.BID, C.CID, C.CNAME", con);
        //    adapt.Fill(ds);
        //    chart1.DataSource = ds;
        //    //set the member of the chart data source used to data bind to the X-values of the series  
        //    chart1.Series["PNAME"].XValueMember = "PNAME";
        //    //set the member columns of the chart data source used to data bind to the X-values of the series  
        //    chart1.Series["PNAME"].YValueMembers = "STOCK";
        //    //chart1.Titles.Add("PNAME Chart");
        //    con.Close();
        //}
    }
}
