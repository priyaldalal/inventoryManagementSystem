﻿using System;
using INVENT.BAL;
using INVENT.DAL;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Web;
using System.Threading.Tasks;

namespace INVENT.BLL
{
    internal class BLL_USER
    {
        public string ManageUser(BAL_USER objBal)
        {
            DAL_USER objDal = new DAL_USER();
            return objDal.ManageUser(objBal);
        }
        public DataTable GetALl(BAL_USER objBal)
        {
            DAL_USER objDal = new DAL_USER();
            return objDal.GetALl(objBal);
        }
        public DataTable GETDETAIL(BAL_USER objBal)
        {
            DAL_USER objDal = new DAL_USER();
            return objDal.GETDETAIL(objBal);
        }
        //public string UPDATEUSER(BAL_USER objBal)
        //{
        //    DAL_USER objDal = new DAL_USER();
        //    return objDal.UPDATEUSER(objBal);
        //}
        public string UPDATE(BAL_USER objBal)
        {
            DAL_USER objDal = new DAL_USER();
            return objDal.UPDATE(objBal);
        }
        public DataTable GetData(BAL_USER objBal)
        {
            DAL_USER objDal = new DAL_USER();
            return objDal.GetData(objBal);
        }
        public string Delete(BAL_USER objBal)
        {
            DAL_USER ObjDal = new DAL_USER();
            return ObjDal.Delete(objBal);
        }
        //public DataTable GetFileView(BAL_USER objBal)
        //{
        //    DAL_USER objDal = new DAL_USER();
        //    return objDal.GetFileView(objBal);
        //}
    }
}
