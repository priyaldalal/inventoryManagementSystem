﻿using System;
using INVENT.BAL;
using INVENT.DAL;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INVENT.BLL
{
    internal class BLL_PRODUCT
    {
        public DataTable Getcategory(BAL_PRODUCT objBal)
        {
            DAL_PRODUCT ObjDal = new DAL_PRODUCT();
            return ObjDal.Getcategory(objBal);
        }
        public DataTable GetBRAND(BAL_PRODUCT objBal)
        {
            DAL_PRODUCT ObjDal = new DAL_PRODUCT();
            return ObjDal.GetBRAND(objBal);
        }
        public string product(BAL_PRODUCT objBal)
        {
            DAL_PRODUCT ObjDal = new DAL_PRODUCT();
            return ObjDal.product(objBal);
        }
        public DataTable GetALl(BAL_PRODUCT objBal)
        {
            DAL_PRODUCT ObjDal = new DAL_PRODUCT();
            return ObjDal.GetALl(objBal);
        }
        public DataTable GetALl2(BAL_PRODUCT objBal)
        {
            DAL_PRODUCT ObjDal = new DAL_PRODUCT();
            return ObjDal.GetALl2(objBal);
        }
        public DataTable GETDETAIL(BAL_PRODUCT objBal)
        {
            DAL_PRODUCT ObjDal = new DAL_PRODUCT();
            return ObjDal.GETDETAIL(objBal);
        }

        public string Delete(BAL_PRODUCT objBal)
        {
            DAL_PRODUCT ObjDal = new DAL_PRODUCT();
            return ObjDal.Delete(objBal);
        }
        public string UPDATE(BAL_PRODUCT objBal)
        {
            DAL_PRODUCT ObjDal = new DAL_PRODUCT();
            return ObjDal.UPDATE(objBal);
        }
        public string Productupdate(BAL_PRODUCT objBal)
        {
            DAL_PRODUCT ObjDal = new DAL_PRODUCT();
            return ObjDal.Productupdate(objBal);
        }
    }
}
