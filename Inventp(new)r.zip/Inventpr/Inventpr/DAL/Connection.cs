﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;


namespace INVENT.DAL
{
    internal class Connection
    {
        public SqlCommand cmd;
        public SqlConnection con;
        //public SqlConnection conSL;
        public SqlDataAdapter da;
        //public SqlDataAdapter dr1;
        public DataSet ds;
        public DataTable dt;
        //public double max;
        public string msg = "";

        public void Connect()
        {
            con = new SqlConnection(@"data source=DESKTOP-C32MIJ1\SQLEXPRESS;initial catalog=Inventory; user id=sa;password=1234;max pool size=1024");
            // con = new SqlConnection(@"data source=CMP28\SQL16;initial catalog=FFWDESKMAIN; user id=sa;password=jinee@123;max pool size=1024");
            //con = new SqlConnection(@"data source=CMP28\SQLEXPRESS;initial catalog=FFWDESKMAIN; user id=sa;password=jinee@123;max pool size=1024");
            con.Open();
            cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandTimeout = 0;
            da = new SqlDataAdapter(cmd);
            ds = new DataSet();
            dt = new DataTable();

        }
        public void disconnect()
        {
            con.Close();
        }
    }
}
