﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using INVENT.BAL;
using System.Data;



namespace INVENT.DAL
{
    internal class DAL_USER: Connection
    {
        string str = "";
        public string ManageUser(BAL_USER objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_INSERT_USER";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "INSERT");
                cmd.Parameters.AddWithValue("USERNAME", objBal.USERNAME);
                cmd.Parameters.AddWithValue("EMAIL", objBal.EMAIL);
                cmd.Parameters.AddWithValue("PASSWORD", objBal.PASSWORD);
                cmd.Parameters.AddWithValue("FNAME", objBal.FNAME);
                cmd.Parameters.AddWithValue("LNAME", objBal.LNAME);

                cmd.Parameters.Add("MSG", SqlDbType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                str = cmd.Parameters["MSG"].Value.ToString();
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            finally
            {
                disconnect();
            }
            return str;
        }
        public DataTable GetALl(BAL_USER objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_INSERT_USER";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "SELALL");
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            finally
            {
                disconnect();
            }
            return dt;
        }

        public DataTable GETDETAIL(BAL_USER objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_INSERT_USER";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "SELALL1");
                cmd.Parameters.AddWithValue("USERID", objBal.USERID);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
            }
            finally
            {
                disconnect();
            }
            return dt;
        }



        //public string UPDATEUSER(BAL_USER objBal)
        //{
        //    try
        //    {
        //        Connect();
        //        cmd.Connection = con;
        //        cmd.CommandText = "dbo.SP_INSERT_USER";
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.Parameters.AddWithValue("ACTION", "UPDATE");
        //        cmd.Parameters.AddWithValue("USERID", objBal.USERID);
        //        cmd.Parameters.AddWithValue("USERNAME", objBal.USERNAME);
        //        cmd.Parameters.AddWithValue("EMAIL", objBal.EMAIL);
        //        cmd.Parameters.AddWithValue("PASSWORD", objBal.PASSWORD);
        //        cmd.Parameters.AddWithValue("FNAME", objBal.FNAME);
        //        cmd.Parameters.AddWithValue("LNAME", objBal.LNAME);
        //        byte[] imageBytes = Convert.FromBase64String(objBal.FileUpload);
        //        cmd.Parameters.Add("DOC", SqlDbType.VarBinary);
        //        cmd.Parameters["DOC"].Value = imageBytes;
        //        cmd.Parameters.AddWithValue("FILENAME", objBal.FileName);
        //        cmd.Parameters.AddWithValue("FILEEXT", objBal.FileExt);


        //        cmd.Parameters.Add("MSG", SqlDbType.VarChar, 1000).Direction = ParameterDirection.Output;
        //        cmd.ExecuteNonQuery();
        //        str = cmd.Parameters["MSG"].Value.ToString();
        //    }
        //    catch (Exception ex)
        //    {
        //        str = ex.Message;
        //    }
        //    finally
        //    {
        //        disconnect();
        //    }
        //    return str;
        //}
        public string UPDATE(BAL_USER objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_INSERT_USER";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "UPDATEREGISTER");
                cmd.Parameters.AddWithValue("USERID", objBal.USERID);
                cmd.Parameters.AddWithValue("USERNAME", objBal.USERNAME);
                cmd.Parameters.AddWithValue("EMAIL", objBal.EMAIL);
                cmd.Parameters.AddWithValue("PASSWORD", objBal.PASSWORD);
                cmd.Parameters.AddWithValue("FNAME", objBal.FNAME);
                cmd.Parameters.AddWithValue("LNAME", objBal.LNAME);



                cmd.Parameters.Add("MSG", SqlDbType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                str = cmd.Parameters["MSG"].Value.ToString();
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            finally
            {
                disconnect();
            }
            return str;
        }
        public DataTable GetData(BAL_USER objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_INSERT_USER";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "SELMENUBYLOGIN");

                cmd.Parameters.AddWithValue("USERID", objBal.USERID);
                cmd.Parameters.AddWithValue("FNAME", objBal.FNAME);
                cmd.Parameters.AddWithValue("LNAME", objBal.LNAME);
                cmd.Parameters.AddWithValue("USERNAME", objBal.USERNAME);
                cmd.Parameters.AddWithValue("PASSWORD", objBal.PASSWORD);

                da.Fill(dt);
            }
            catch (Exception)
            {
            }
            finally
            {
                disconnect();
            }
            return dt;
        }

        public string Delete(BAL_USER objBal)
        {
            str = "";
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_INSERT_USER";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "DELETE");
                cmd.Parameters.AddWithValue("USERID", objBal.USERID);

                cmd.Parameters.Add("MSG", SqlDbType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                str = cmd.Parameters["MSG"].Value.ToString();
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            finally
            {
                disconnect();
            }
            return str;
        }
        //public DataTable GetFileView(BAL_USER objBal)
        //{
        //    try
        //    {
        //        Connect();
        //        cmd.Connection = con;
        //        cmd.CommandText = "dbo.SP_INSERT_USER";
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.Parameters.AddWithValue("ACTION", objBal.ACTION);
        //        cmd.Parameters.AddWithValue("USERID", objBal.UPLOADID);
        //        //cmd.Parameters.AddWithValue("USERID", objBal.UserID);
        //        da.Fill(dt);
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    finally
        //    {
        //        disconnect();
        //    }
        //    return dt;
        //}
    }
}
