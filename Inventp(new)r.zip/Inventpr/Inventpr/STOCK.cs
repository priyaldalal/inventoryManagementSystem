﻿using INVENT.BAL;
using INVENT.BLL;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Drawing;
using System.Collections.Generic;
using System.ComponentModel;




using System.IO;



namespace Inventpr
{
    public partial class STOCK : Form
    {

        public STOCK()
        {
            InitializeComponent();
        }

        private void STOCK_Load(object sender, EventArgs e)
        {
            BAL_PRODUCT objBal = new BAL_PRODUCT();
            BLL_PRODUCT objBll = new BLL_PRODUCT();

            DataTable dt = objBll.GetALl2(objBal);
            dataGridView1.DataSource = dt.DefaultView;
            fillChart();
        }

        private void BACK_Click(object sender, EventArgs e)
        {
            this.Hide();
            var Form2 = new Form2();
            Form2.Closed += (s, args) => this.Close();
            Form2.Show();
        }

        private void Refresh_Click(object sender, EventArgs e)
        {
            //BAL_PRODUCT objBal = new BAL_PRODUCT();
            //BLL_PRODUCT objBll = new BLL_PRODUCT();

            //DataTable dt = objBll.GetALl2(objBal);
            //dataGridView1.DataSource = dt.DefaultView;
            this.Hide();
            var STOCK = new STOCK();
            STOCK.Closed += (s, args) => this.Close();
            STOCK.Show();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {






        }

        private void fillChart()
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-C32MIJ1\\SQLEXPRESS;Initial Catalog=Inventory;User ID=sa;Password=1234;");
            //qlConnection con = new SqlConnection("Data Source=.;Initial Catalog=Sample;Integrated Security=true;");
            DataSet ds = new DataSet();
            con.Open();
            SqlDataAdapter adapt = new SqlDataAdapter("Select sum(Case when isnull(IOENT,'I')='I' then QUNTITY when isnull(IOENT,'I')='O' then -1*QUNTITY end) as STOCK,PNAME from PRODUCT   GROUP BY PNAME", con);
            adapt.Fill(ds);
            chart1.DataSource = ds;
            //set the member of the chart data source used to data bind to the X-values of the series  
            chart1.Series["QUALITY"].XValueMember = "PNAME";
            //set the member columns of the chart data source used to data bind to the X-values of the series  
            chart1.Series["QUALITY"].YValueMembers = "STOCK";
            chart1.Titles.Add("QUALITY Chart");
            con.Close();
        }
        private void chart1_Click(object sender, EventArgs e)
        {

        }
    }
}
