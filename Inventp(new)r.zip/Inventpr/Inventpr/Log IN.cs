﻿using System;
using INVENT.BAL;
using INVENT.BLL;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventpr
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.ActiveControl = textusername;
           /// this.ActiveControl = textpassword;
            textusername.Focus();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str = "";
            try
            {
                BAL_USER objBal = new BAL_USER();
                BLL_USER objBll = new BLL_USER();

                objBal.USERNAME = textusername.Text;
                objBal.PASSWORD = textpassword.Text;


                DataTable dtLogin = objBll.GetData(objBal);
                if (dtLogin.Rows.Count > 0)
                {
                    string pass = dtLogin.Rows[0]["PASSWORD"].ToString();
                    if (pass == textpassword.Text)
                    {
                        //ssageBox.Show("LOG IN SUCESS");
                        //INVENTORY frm2 = new INVENTORY();
                        //frm2.Show();

                        //str = "y";
                        this.Hide();
                        var FORM2 = new Form2();
                        FORM2.Closed += (s, args) => this.Close();
                        FORM2.Show();

                    }
                    else
                    {
                        MessageBox.Show("P/Incorrect password..!");
                    }
                }
                else
                {
                    MessageBox.Show("U/Invalid username or credentials..!");
                }
            }
            catch (Exception ex)
            {
                str = ex.Message.ToString();
            }

        
        }
        public static string Logout()
        {

            return "y";
        }
       
        private void textusername_TextChanged(object sender, EventArgs e)
        {
           
        }
    }
}
