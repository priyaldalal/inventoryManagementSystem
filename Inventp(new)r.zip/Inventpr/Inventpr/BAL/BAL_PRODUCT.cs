﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INVENT.BAL
{
    internal class BAL_PRODUCT
    {
        public string ACTION { get; set; }
        public string PID { get; set; }
        public int USERID { get; set; }
        public string PNAME { get; set; }
        public string DISCRIPTION { get; set; }
        public string CATEGORY { get; set; }

        public string BRAND { get; set; }
        public string STATUS { get; set; }
        public string COST { get; set; }
        public string PDATE { get; set; }
        public string DATE { get; set; }
        public string IOENT { get; set; }

        public int CID { get; set; }
        public string CNAME { get; set; }

        public int BID { get; set; }
        public string QUNTITY { get; set; }
        public string BNAME { get; set; }
        public string BDISCRIPTION { get; set; }
    }
}
