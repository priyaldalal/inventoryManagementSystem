﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INVENT.BAL
{
    internal class BAL_USER
    {
        public string USERID { get; set; }
        public string USERNAME { get; set; }
        public string EMAIL { get; set; }
        public string PASSWORD { get; set; }

        public string FNAME { get; set; }
        public string LNAME { get; set; }
    }
}
