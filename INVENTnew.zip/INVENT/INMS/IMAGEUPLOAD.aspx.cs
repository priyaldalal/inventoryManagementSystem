﻿using INMS.BAL;
using INMS.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;


namespace INMS
{
    public partial class IMAGEUPLOADaspx : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
          [WebMethod]
        public static string Save(string[][] FILES)
        {
            string str = "";
            BAL_FILE objBal = new BAL_FILE();
            BLL_FILE objBll = new BLL_FILE();
            //BLL_COLOUR_MASTER objBll = new BLL_COLOUR_MASTER();
            TimeZoneInfo destinationTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            DateTime indianTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, destinationTimeZone);

            XmlDocument docFileXML = new XmlDocument();
            XmlDeclaration docaddress2 = docFileXML.CreateXmlDeclaration("1.0", null, null);
            XmlElement docAddress3 = docFileXML.CreateElement("Main");
            docFileXML.InsertBefore(docaddress2, docFileXML.DocumentElement);
            docFileXML.AppendChild(docAddress3);
            int index = 1;
            foreach (var arr in FILES)
            {
                XmlElement termselement4 = docFileXML.CreateElement("Sub");
                docFileXML.DocumentElement.PrependChild(termselement4);

                XMLHandler.CreateXMLEle(ref docFileXML, ref termselement4, "SRNO", index.ToString());
                XMLHandler.CreateXMLEle(ref docFileXML, ref termselement4, "DOCUMENT", arr[0]);
                XMLHandler.CreateXMLEle(ref docFileXML, ref termselement4, "DOCTITLE", arr[1]);
                XMLHandler.CreateXMLEle(ref docFileXML, ref termselement4, "DOCEXT", arr[2]);
                index++;
            }

            string Document = XMLHandler.ConvertXMLtoString(docFileXML);


            objBal.ACTION = "INSENTRY";
            objBal.DOCUMENTXML = Document;

            str = objBll.ManageEntry(objBal);
            return str;
        }
        //public static string getDetail(string UPLOADID)
        //{
        //    string str = "";
        //    BAL_FILE objBal = new BAL_FILE();
        //    UPLOADID = HttpContext.Current.Server.UrlDecode(UPLOADID);
        //    objBal.ACTION = "SELENTRY";
        //    objBal.UPLOADID = Convert.ToInt32(UPLOADID);
        //    DataSet ds = objBal.ManageData(objBal);
        //    ds.Tables[0].TableName = "tblData";
        //    ds.Tables[1].TableName = "tblDoc";

        //    //for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
        //    //{
        //    //    ds.Tables[1].Rows[i]["DOCFILE"] = clscommon.Encrypt(ds.Tables[1].Rows[i]["ID"].ToString());
        //    //}

        //    for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
        //    {
        //        ds.Tables[1].Rows[i]["ID"] = clscommon.Encrypt(ds.Tables[1].Rows[i]["ID"].ToString());
        //        if (ds.Tables[1].Rows[i]["DOCUMENT"].ToString() != "")
        //        {
        //            Byte[] bytes = (Byte[])ds.Tables[1].Rows[i]["DOCUMENT"];
        //            string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
        //            base64String = "data:image/png;base64," + base64String;
        //            ds.Tables[1].Rows[i]["DOCFILE"] = base64String;
        //        }
        //    }
        //    using (StringWriter sw = new StringWriter())
        //    {
        //        ds.WriteXml(sw);
        //        str = sw.ToString();
        //    }
        //    return str;
        //}

        //[WebMethod]
        //public static string delData(int UPLOADID)
        //{
        //    string str = "";

        //    try
        //    {
        //        //clscommon.IsUsed("TBILED", "SHIFTCODE='" + SHIFTCODE + "' and  COCODE='" + HttpContext.Current.Session["COCODE"].ToString() + "' ");

        //        BAL_FILE objBal = new BAL_FILE();
        //        //BLL_COLOUR_MASTER objBll = new BLL_COLOUR_MASTER();
        //        objBal.ACTION = "DELENTRY";
        //        objBal.UPLOADID = Convert.ToInt32(UPLOADID);
        //        str = objBal.MasterData(objBal);
        //    }
        //    catch (Exception ex)
        //    {
        //        if (ex.Message == "USED")
        //            str = "you can not delete this record.It is being used in entry!";
        //    }

        //    return str;
        //}
        ////[WebMethod]
        //public static string getDataSet(string SEARCHTEXT, int PAGEINDEX)
        //{
        //    string str = "";
        //    int PageSize = 30;
        //    BAL_WH_INSPECTION_ENTRY objBal = new BAL_WH_INSPECTION_ENTRY();

        //    objBal.Action = "GETALLENTRY";
        //    objBal.SearchText = SEARCHTEXT;
        //    objBal.PageIndex = PAGEINDEX;
        //    objBal.PageSize = PageSize;
        //    DataSet ds = objBal.ManageDataSet(objBal);
        //    //dt.TableName = "tblData";
        //    if (ds.Tables.Count > 0)
        //    {
        //        ds.Tables[0].TableName = "tblData";
        //        DataTable table = new DataTable("Pager");
        //        table.Columns.Add("PageIndex");
        //        table.Columns.Add("PageSize");
        //        table.Columns.Add("RecordCount");
        //        table.Rows.Add(new object[0]);
        //        table.Rows[0]["PageIndex"] = PAGEINDEX;
        //        table.Rows[0]["PageSize"] = PageSize;
        //        table.Rows[0]["RecordCount"] = ds.Tables[1].Rows[0][0].ToString();
        //        ds.Tables.RemoveAt(1);
        //        ds.Tables.Add(table);
        //        str = ds.GetXml();
        //    }
        //    return str;
        //}
          [System.Web.Services.WebMethod]
          public static string GetAll()
          {
              string str = "";
              BAL_FILE objBal = new BAL_FILE();
              BLL_FILE objBll = new BLL_FILE();

              DataTable dt = objBll.GetALl(objBal);

              dt.TableName = "tblData";
              using (StringWriter sw = new StringWriter())
              {
                  dt.WriteXml(sw);
                  str = sw.ToString();
              }
              return str;
          }

          [System.Web.Services.WebMethod]
          public static string GETDETAIL(string UPLOADID)
          {
              string str = "";
              BAL_FILE objBal = new BAL_FILE();
              BLL_FILE objBll = new BLL_FILE();

              objBal.UPLOADID = UPLOADID;
              DataTable dt = objBll.GETDETAIL(objBal);

              dt.TableName = "tblData";
              using (StringWriter sw = new StringWriter())
              {
                  dt.WriteXml(sw);
                  str = sw.ToString();
              }
              return str;
          }
    }
    
}