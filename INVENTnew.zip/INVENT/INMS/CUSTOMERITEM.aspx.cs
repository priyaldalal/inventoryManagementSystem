﻿
using INMS.BAL;
using INMS.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace INMS
{
    public partial class CUTOMERITEM : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        [WebMethod]
        public static string Save(string CNAME, string INVNO, string CDATE, string USERID, string[][] ITEMDTLXML)
        {
            string str = "";
            BAL_ITEM objBal = new BAL_ITEM();
            BLL_ITEM objBll = new BLL_ITEM();
            //BLL_COLOUR_MASTER objBll = new BLL_COLOUR_MASTER();
            TimeZoneInfo destinationTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            DateTime CURRENTDATE = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, destinationTimeZone);

            XmlDocument docFileXML = new XmlDocument();
            XmlDeclaration docaddress2 = docFileXML.CreateXmlDeclaration("1.0", null, null);
            XmlElement docAddress3 = docFileXML.CreateElement("Main");
            docFileXML.InsertBefore(docaddress2, docFileXML.DocumentElement);
            docFileXML.AppendChild(docAddress3);
            int index = 1;
            foreach (var arr in ITEMDTLXML)
            {
                XmlElement termselement4 = docFileXML.CreateElement("Sub");
                docFileXML.DocumentElement.PrependChild(termselement4);

                XMLHandler.CreateXMLEle(ref docFileXML, ref termselement4, "SRNO", index.ToString());
                XMLHandler.CreateXMLEle(ref docFileXML, ref termselement4, "ITEMNAME", arr[0]);
                XMLHandler.CreateXMLEle(ref docFileXML, ref termselement4, "RATE", arr[1]);
                //XMLHandler.CreateXMLEle(ref docFileXML, ref termselement4, "DOCEXT", arr[2]);
                index++;
            }

            string Document = XMLHandler.ConvertXMLtoString(docFileXML);



            objBal.ACTION = "INSERT";

            objBal.CNAME = CNAME;
            objBal.INVNO = INVNO;
            objBal.CDATE = clsCommon.ConvertToDateTime(CDATE);
            objBal.ITEMDTLXML = Document;

            objBal.USERID = USERID;
            objBal.CURRENTDATE = CURRENTDATE;
            str = objBll.ManageEntry(objBal);
            return str;



            //str = objBll.ManageEntry(objBal);
            //return str;
        }

        [System.Web.Services.WebMethod]
        public static string GetAll()
        {
            string str = "";
            BAL_ITEM objBal = new BAL_ITEM();
            BLL_ITEM objBll = new BLL_ITEM();

            DataTable dt = objBll.GetALl(objBal);

            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;
        }
        [System.Web.Services.WebMethod]
        public static string GETDETAIL(int CID)
        {
            string str = "";
            BAL_ITEM objBal = new BAL_ITEM();
            BLL_ITEM objBll = new BLL_ITEM();

            objBal.CID = CID;
            DataSet ds = objBll.GETDETAIL(objBal);

            ds.Tables[0].TableName = "tblData";
            ds.Tables[1].TableName = "tblItem";
            using (StringWriter sw = new StringWriter())
            {
                ds.WriteXml(sw);
                str = sw.ToString();
            }
            return str;
        }
        [WebMethod]
        public static string GetCUSTOMER()
        {
            string str = "";

            BAL_ITEM objBal = new BAL_ITEM();
            BLL_ITEM objBll = new BLL_ITEM();
            objBal.ACTION = "BINDCUSTOMER";
            DataTable dt = objBll.GetCUSTOMER(objBal);
            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;

        }
        [System.Web.Services.WebMethod]
        public static string UPDATE(string CID, string CNAME, string INVNO, string CDATE, string USERID, string[][] ITEMDTLXML)
        {

            string str = "";
            BAL_ITEM objBal = new BAL_ITEM();
            BLL_ITEM objBll = new BLL_ITEM();
            //BLL_COLOUR_MASTER objBll = new BLL_COLOUR_MASTER();
            TimeZoneInfo destinationTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            DateTime CURRENTDATE = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, destinationTimeZone);

            XmlDocument docFileXML = new XmlDocument();
            XmlDeclaration docaddress2 = docFileXML.CreateXmlDeclaration("1.0", null, null);
            XmlElement docAddress3 = docFileXML.CreateElement("Main");
            docFileXML.InsertBefore(docaddress2, docFileXML.DocumentElement);
            docFileXML.AppendChild(docAddress3);
            int index = 1;
            foreach (var arr in ITEMDTLXML)
            {
                XmlElement termselement4 = docFileXML.CreateElement("Sub");
                docFileXML.DocumentElement.PrependChild(termselement4);

                XMLHandler.CreateXMLEle(ref docFileXML, ref termselement4, "SRNO", index.ToString());
                XMLHandler.CreateXMLEle(ref docFileXML, ref termselement4, "ITEMNAME", arr[0]);
                XMLHandler.CreateXMLEle(ref docFileXML, ref termselement4, "RATE", arr[1]);
                //XMLHandler.CreateXMLEle(ref docFileXML, ref termselement4, "DOCEXT", arr[2]);
                index++;
            }

            string Document = XMLHandler.ConvertXMLtoString(docFileXML);

            objBal.ACTION = "UPDATE";
            objBal.CID =Convert.ToInt16(CID);
            objBal.CNAME = CNAME;
            objBal.INVNO = INVNO;
            objBal.CDATE = clsCommon.ConvertToDateTime(CDATE);
            objBal.ITEMDTLXML = Document;

            objBal.USERID = USERID;
            objBal.CURRENTDATE = CURRENTDATE;
            str = objBll.ManageEntry(objBal);
            return str;
        }


    }
}