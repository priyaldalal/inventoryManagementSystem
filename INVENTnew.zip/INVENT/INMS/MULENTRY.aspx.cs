﻿using INMS.BAL;
using INMS.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace INMS
{
    public partial class MULENTRY : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        //[WebMethod]
        //public static string Save(int PCODE, string[][] VISITXML)
        //{

        //    string str = "";

        //    XmlDocument docIledXML = new XmlDocument();
        //    XmlDeclaration address2 = docIledXML.CreateXmlDeclaration("1.0", null, null);
        //    XmlElement addresse3 = docIledXML.CreateElement("Main");
        //    docIledXML.InsertBefore(address2, docIledXML.DocumentElement);
        //    docIledXML.AppendChild(addresse3);

        //    foreach (var arr in VISITXML)
        //    {
        //        XmlElement termselement4 = docIledXML.CreateElement("Sub");
        //        docIledXML.DocumentElement.PrependChild(termselement4);

        //        XMLHandler.CreateXMLEle(ref docIledXML, ref termselement4, "CATEGORYCODE", arr[0]);
        //        XMLHandler.CreateXMLEle(ref docIledXML, ref termselement4, "VISITTYPE", arr[1]);
        //        XMLHandler.CreateXMLEle(ref docIledXML, ref termselement4, "MONDAY", arr[2]);
        //        XMLHandler.CreateXMLEle(ref docIledXML, ref termselement4, "TUESDAY", arr[3]);
        //        XMLHandler.CreateXMLEle(ref docIledXML, ref termselement4, "WEDNESDAY", arr[4]);
        //        XMLHandler.CreateXMLEle(ref docIledXML, ref termselement4, "THURSDAY", arr[5]);
        //        XMLHandler.CreateXMLEle(ref docIledXML, ref termselement4, "FRIDAY", arr[6]);
        //        XMLHandler.CreateXMLEle(ref docIledXML, ref termselement4, "SATURDAY", arr[7]);
        //        XMLHandler.CreateXMLEle(ref docIledXML, ref termselement4, "SUNDAY", arr[8]);
        //    }
        //    string ILEDXML = XMLHandler.ConvertXMLtoString(docIledXML);

        //    BAL_MUL objBal = new BAL_MUL();
        //    BLL_MUL objBll = new BLL_MUL();
        //    if (PCODE == "")
        //    {
        //        objBal.Action = "INSDOC";
        //    }
        //    else
        //    {
        //        objBal.Action = "UPDDOC";
        //    }

        //    objBal.BranchCode = CurrentSession.GetBranchCode();
        //    objBal.UserID = CurrentSession.GetUserID();
        //    objBal.EntryDate = clscommon.GetTodayDate();
        //    str = objBll.ManageDoctor(objBal);
        //    return str;
        //}
    }
}