﻿using INMS.BAL;
using INMS.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;


namespace INMS
{
    public partial class USERACCOUNT : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (HttpContext.Current.Session["PRIYALUSERID"] == null || HttpContext.Current.Session["PRIYALUSERNAME"].ToString() == "")
            {
                Response.Redirect("Login.aspx");
            }
            
        }
        [System.Web.Services.WebMethod]
        public static string GETDETAIL(int USERID)
        {
            string str = "";
            BAL_USER objBal = new BAL_USER();
            BLL_USER objBll = new BLL_USER();

            objBal.USERID = USERID;
            DataTable dt = objBll.GETDETAIL(objBal);

            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;
        }
        
    }
}