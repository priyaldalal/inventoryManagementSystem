﻿using INMS.BAL;
using INMS.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace INMS
{
    public partial class CATEGORY : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [System.Web.Services.WebMethod]
        public static string Save(string CNAME)
        {
            string str = "";
            BAL_CAT objBal = new BAL_CAT();
            BLL_CAT objBll = new BLL_CAT();

            objBal.CNAME = CNAME;
          
            str = objBll.ManageUser(objBal);

            return str;
        }
        [System.Web.Services.WebMethod]
        public static string GetAll()
        {
            string str = "";
            BAL_CAT objBal = new BAL_CAT();
            BLL_CAT objBll = new BLL_CAT();

            DataTable dt = objBll.GetALl(objBal);

            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;
        }

        [System.Web.Services.WebMethod]
        public static string GETDETAIL(int CID)
        {
            string str = "";
            BAL_CAT objBal = new BAL_CAT();
            BLL_CAT objBll = new BLL_CAT();

            objBal.CID = CID;
            DataTable dt = objBll.GETDETAIL(objBal);

            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;
        }

        [System.Web.Services.WebMethod]
        public static string UPDATEUSER(int CID, string CNAME)
        {
            string str = "";
            BAL_CAT objBal = new BAL_CAT();
            BLL_CAT objBll = new BLL_CAT();

            objBal.CID = CID;
            objBal.CNAME = CNAME;
           
            str = objBll.UPDATEUSER(objBal);

            return str;
        }
        [System.Web.Services.WebMethod]
        public static string DELETE(int CID)
        {
            string str = "";
            BAL_CAT objBal = new BAL_CAT();
            BLL_CAT objBll = new BLL_CAT(); 
            objBal.CID = CID;

            str = objBll.Delete1(objBal);

            return str;
        }
    }
}