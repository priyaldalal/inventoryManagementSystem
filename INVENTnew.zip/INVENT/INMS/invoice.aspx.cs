﻿using System;
using INMS.BAL;
using INMS.BLL;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;

namespace INMS
{
    public partial class invoice : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [WebMethod]
        public static string Getproduct()
        {
            string str = "";

            BAL_PRODUCT objBal = new BAL_PRODUCT();
            BLL_PRODUCT objBll = new BLL_PRODUCT();
            objBal.ACTION = "BINDPRODUCT";
            DataTable dt = objBll.Getproduct(objBal);
            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;

        }
    }
}