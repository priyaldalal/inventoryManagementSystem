﻿using INMS.BAL;
using INMS.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace INMS
{
    public partial class wizadview : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [WebMethod]
        public static string save(string USERNAME, string PASSWORD, string FNAME, string LNAME, string EMAIL, string ADDRES)
        {
            string str = "";
            BAL_R objBal = new BAL_R();
            BLL_R objBll = new BLL_R();

            objBal.USERNAME = USERNAME;
            objBal.PASSWORD = PASSWORD;
            objBal.FNAME = FNAME;
            objBal.LNAME = LNAME;
            objBal.EMAIL = EMAIL;
            objBal.ADDRES = ADDRES;

            str = objBll.Register(objBal);

            return str;
        }
    }
}