﻿using INMS.BAL;
using INMS.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;


namespace INMS.BLL
{
    public class BLL_ITEM
    {
        public string ManageEntry(BAL_ITEM objBal)
        {
            DAL_ITEM ObjDal = new DAL_ITEM();
            return ObjDal.ManageEntry(objBal);
        }
        public string UPDATE(BAL_ITEM objBal)
        {
            DAL_ITEM ObjDal = new DAL_ITEM();
            return ObjDal.UPDATE(objBal);
        }
        public DataTable GetALl(BAL_ITEM objBal)
        {
            DAL_ITEM objDal = new DAL_ITEM();
            return objDal.GetALl(objBal);
        }
        public DataSet GETDETAIL(BAL_ITEM objBal)
        {
            DAL_ITEM objDal = new DAL_ITEM();
            return objDal.GETDETAIL(objBal);
        }
        public DataTable GetCUSTOMER(BAL_ITEM objBal)
        {
            DAL_ITEM ObjDal = new DAL_ITEM();
            return ObjDal.GetCUSTOMER(objBal);
        }
    }
}