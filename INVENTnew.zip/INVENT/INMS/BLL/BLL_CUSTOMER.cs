﻿using INMS.BAL;
using INMS.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace INMS.BLL
{
    public class BLL_CUSTOMER
    {
        public string Savedata(BAL_CUSTOMER objBal)
        {
            DAL_CUSTOMER ObjDal = new DAL_CUSTOMER();
            return ObjDal.Savedata(objBal);
        }
        public DataTable GetALl(BAL_CUSTOMER objBal)
        {
            DAL_CUSTOMER objDal = new DAL_CUSTOMER();
            return objDal.GetALl(objBal);
        }
        public DataTable GETDETAIL(BAL_CUSTOMER objBal)
        {
            DAL_CUSTOMER objDal = new DAL_CUSTOMER();
            return objDal.GETDETAIL(objBal);
        }
        public string UPDATE(BAL_CUSTOMER objBal)
        {

            DAL_CUSTOMER objDal = new DAL_CUSTOMER();
            return objDal.UPDATE(objBal);
        }
        public string Delete(BAL_CUSTOMER objBal)
        {
            DAL_CUSTOMER ObjDal = new DAL_CUSTOMER();
            return ObjDal.Delete(objBal);
        }
    }
}