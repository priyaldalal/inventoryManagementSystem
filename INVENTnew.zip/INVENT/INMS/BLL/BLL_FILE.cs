﻿using INMS.BAL;
using INMS.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace INMS.BLL
{
    public class BLL_FILE
    {
        public string ManageEntry(BAL_FILE objBal)
        {
            DAL_FILE ObjDal = new DAL_FILE();
            return ObjDal.ManageEntry(objBal);
        }
        
        public DataTable GetFileView(BAL_FILE objBal)
        {
            DAL_FILE objDal = new DAL_FILE();
            return objDal.GetFileView(objBal);
        }
        public DataTable GetALl(BAL_FILE objBal)
        {
            DAL_FILE objDal = new DAL_FILE();
            return objDal.GetALl(objBal);
        }
        public DataTable GETDETAIL(BAL_FILE objBal)
        {
            DAL_FILE objDal = new DAL_FILE();
            return objDal.GETDETAIL(objBal);
        }
    }
}