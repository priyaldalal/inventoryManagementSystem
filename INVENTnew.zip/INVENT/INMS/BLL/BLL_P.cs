﻿using INMS.BAL;
using INMS.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace INMS.BLL
{
    public class BLL_P
    {
        //public string product(BAL_P objBal)
        //{
        //    DAL_P ObjDal = new DAL_P();
        //    return ObjDal.product(objBal);
        //}
        public DataTable GetALl(BAL_P objBal)
        {
            DAL_P ObjDal = new DAL_P();
            return ObjDal.GetALl(objBal);
        }
        public DataTable GETDETAIL(BAL_P objBal)
        {
            DAL_P ObjDal = new DAL_P();
            return ObjDal.GETDETAIL(objBal);
        }

        //internal DataTable GetFileView(BAL_P objBal)
        //{
        //    throw new NotImplementedException();
        //}
        public string product(BAL_P objBal)
        {
            DAL_P objDal = new DAL_P();
            return objDal.product(objBal);
        }
        public string UPDATE(BAL_P objBal)
        {

            DAL_P objDal = new DAL_P();
            return objDal.UPDATE(objBal);
        }
        public string Delete(BAL_PRODUCT objBal)
        {
            DAL_PRODUCT ObjDal = new DAL_PRODUCT();
            return ObjDal.Delete(objBal);
        }

        //internal DataTable GETDETAIL(BAL_P objBal)
        //{
        //    throw new NotImplementedException();
        //}

        internal string Delete(BAL_P objBal)
        {
            throw new NotImplementedException();
        }
    }

}