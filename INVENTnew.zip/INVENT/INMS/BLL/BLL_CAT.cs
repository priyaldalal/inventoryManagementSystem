﻿using INMS.BAL;
using INMS.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace INMS.BLL
{
    public class BLL_CAT
    {
        public string ManageUser(BAL_CAT objBal)
        {
            DAL_CAT objDal = new DAL_CAT();
            return objDal.ManageUser(objBal);
        }
        public DataTable GetALl(BAL_CAT objBal)
        {
            DAL_CAT objDal = new DAL_CAT();
            return objDal.GetALl(objBal);
        }
        public DataTable GETDETAIL(BAL_CAT objBal)
        {
            DAL_CAT objDal = new DAL_CAT();
            return objDal.GETDETAIL(objBal);
        }
        public string UPDATEUSER(BAL_CAT objBal)
        {
            DAL_CAT objDal = new DAL_CAT();
            return objDal.UPDATEUSER(objBal);
        }
        public string Delete1(BAL_CAT objBal)
        {
            DAL_CAT objDal = new DAL_CAT();
            return objDal.Delete1(objBal);
        }
       



        //BRAND

        public string BRANDADD(BAL_CAT objBal)
        {
            DAL_CAT objDal = new DAL_CAT(); ;
            return objDal.BRANDADD(objBal);
        }
        public DataTable GETBRAND(BAL_CAT objBal)
        {
            DAL_CAT objDal = new DAL_CAT(); ;
            return objDal.GETBRAND(objBal);
        }
        public DataTable BRANDGETDETAIL(BAL_CAT objBal)
        {
            DAL_CAT objDal = new DAL_CAT(); ;
            return objDal.BRANDGETDETAIL(objBal);
        }
        public string UPDATEUSER1(BAL_CAT objBal)
        {
            DAL_CAT objDal = new DAL_CAT();
            return objDal.UPDATEUSER1(objBal);
        }
        public string Delete(BAL_CAT objBal)
        {
            DAL_CAT objDal = new DAL_CAT();
            return objDal.Delete(objBal);
        }
        public DataTable Getcategory(BAL_CAT objBal)
        {
            DAL_CAT ObjDal = new DAL_CAT();
            return ObjDal.Getcategory(objBal);
        }
       
    }
}