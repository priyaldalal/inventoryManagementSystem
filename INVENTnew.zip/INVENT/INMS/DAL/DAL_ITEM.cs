﻿using INMS.BAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INMS.DAL
{
    public class DAL_ITEM : Conection
    {
        string str = "";
        public string ManageEntry(BAL_ITEM objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_ITEM";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", objBal.ACTION);
                //cmd.Parameters.AddWithValue("ITEMID", objBal.ITEMID);
                cmd.Parameters.AddWithValue("CID", objBal.CID);
                cmd.Parameters.AddWithValue("CNAME", objBal.CNAME);
                cmd.Parameters.AddWithValue("INVNO", objBal.INVNO);
                cmd.Parameters.AddWithValue("CURRENTDATE", objBal.CURRENTDATE);

                cmd.Parameters.AddWithValue("CDATE", objBal.CDATE);
                cmd.Parameters.AddWithValue("USERID", objBal.USERID);

                cmd.Parameters.AddWithValue("ITEMDTLXML", objBal.ITEMDTLXML);


                cmd.Parameters.Add("MSG", SqlDbType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                str = cmd.Parameters["MSG"].Value.ToString();
                //objBal.EntryStatus = str;
                //objBal.CLRCODE = cmd.Parameters["CLRCODE"].Value.ToString();
            }
            catch (Exception ex)
            {
                str = "n";
            }
            finally
            {
                disconnect();
            }
            return str;
        }
        public DataSet GETDETAIL(BAL_ITEM objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_ITEM";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "SELITEM");
                cmd.Parameters.AddWithValue("CID", objBal.CID);
                da.Fill(ds);
            }
            catch (Exception ex)
            {
            }
            finally
            {
                disconnect();
            }
            return ds;
        }


        public string UPDATE(BAL_ITEM objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_ITEM";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "UPDATE");
                //cmd.Parameters.AddWithValue("ACTION", objBal.ACTION);
                //cmd.Parameters.AddWithValue("ITEMID", objBal.ITEMID);
                cmd.Parameters.AddWithValue("CID", objBal.CID);
                cmd.Parameters.AddWithValue("CNAME", objBal.CNAME);
                cmd.Parameters.AddWithValue("INVNO", objBal.INVNO);
                cmd.Parameters.AddWithValue("CURRENTDATE", objBal.CURRENTDATE);
                cmd.Parameters.AddWithValue("CDATE", objBal.CDATE);
                cmd.Parameters.AddWithValue("USERID", objBal.USERID);

                cmd.Parameters.AddWithValue("ITEMDTLXML", objBal.ITEMDTLXML);


                cmd.Parameters.Add("MSG", SqlDbType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                str = cmd.Parameters["MSG"].Value.ToString();
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            finally
            {
                disconnect();
            }
            return str;
        }

        public DataTable GetALl(BAL_ITEM objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_ITEM";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "SELALL");
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            finally
            {
                disconnect();
            }
            return dt;
        }

        public DataTable GetCUSTOMER(BAL_ITEM objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_ITEM";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", objBal.ACTION);
                cmd.Parameters.AddWithValue("ITEMID", objBal.ITEMID);

                cmd.Parameters.AddWithValue("CNAME", objBal.CNAME);


                da.Fill(dt);
            }
            catch (Exception ex)
            {
            }
            finally
            {
                disconnect();
            }
            return dt;
        }

    }
}