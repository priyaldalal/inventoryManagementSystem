﻿using INMS.BAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace INMS.DAL
{
    public class DAL_STOCK : Conection
    {

        string str = "";
        public string ManageUser(BAL_STOCK objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_STOCK";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "INSERT");
                cmd.Parameters.AddWithValue("USERID", objBal.USERID);
                cmd.Parameters.AddWithValue("QUALITY", objBal.QUALITY);
                cmd.Parameters.AddWithValue("PNAME", objBal.PNAME);
                cmd.Parameters.AddWithValue("BRAND", objBal.BRAND);
                cmd.Parameters.AddWithValue("CATEGORY", objBal.CATEGORY);
                cmd.Parameters.AddWithValue("AVALIBALITY", objBal.AVALIBALITY);
                cmd.Parameters.AddWithValue("COST", objBal.COST);
                cmd.Parameters.AddWithValue("DATE", objBal.DATE);




                cmd.Parameters.Add("MSG", SqlDbType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                str = cmd.Parameters["MSG"].Value.ToString();
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            finally
            {
                disconnect();
            }
            return str;
        }


        public DataTable GETDETAIL(BAL_STOCK objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_STOCK";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "SEL");
                cmd.Parameters.AddWithValue("STOCKID", objBal.STOCKID);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
            }
            finally
            {
                disconnect();
            }
            return dt;
        }



        public string UPDATEUSER(BAL_STOCK objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_STOCK";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "UPDATE");
                cmd.Parameters.AddWithValue("USERID", objBal.USERID);
                cmd.Parameters.AddWithValue("STOCKID", objBal.STOCKID);
                cmd.Parameters.AddWithValue("QUALITY", objBal.QUALITY);
                cmd.Parameters.AddWithValue("AVALIBALITY", objBal.AVALIBALITY);
                cmd.Parameters.AddWithValue("COST", objBal.COST);
                cmd.Parameters.AddWithValue("DATE", objBal.DATE);

                cmd.Parameters.Add("MSG", SqlDbType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                str = cmd.Parameters["MSG"].Value.ToString();
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            finally
            {
                disconnect();
            }
            return str;
        }


        public DataTable GetALl(BAL_STOCK objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_STOCK";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "SELALL");
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            finally
            {
                disconnect();
            }
            return dt;
        }
        public string Delete(BAL_STOCK objBal)
        {
            str = "";
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_STOCK";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "DELETE");
                cmd.Parameters.AddWithValue("STOCKID", objBal.STOCKID);

                cmd.Parameters.Add("MSG", SqlDbType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                str = cmd.Parameters["MSG"].Value.ToString();
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            finally
            {
                disconnect();
            }
            return str;
        }

        public DataTable GetPRODUCT(BAL_STOCK objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_STOCK";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", objBal.ACTION);
                cmd.Parameters.AddWithValue("PID", objBal.PID);

                cmd.Parameters.AddWithValue("PNAME", objBal.PNAME);
                cmd.Parameters.AddWithValue("BRAND", objBal.BRAND);
                cmd.Parameters.AddWithValue("CATEGORY", objBal.CATEGORY);


                da.Fill(dt);
            }
            catch (Exception ex)
            {
            }
            finally
            {
                disconnect();
            }
            return dt;
        }
        public DataTable GetBRAND(BAL_STOCK objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_PRODUCT";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", objBal.ACTION);
                cmd.Parameters.AddWithValue("CATEGORY", objBal.CATEGORY);
                cmd.Parameters.AddWithValue("BID", objBal.BID);
                cmd.Parameters.AddWithValue("BNAME", objBal.BNAME);

                da.Fill(dt);
            }
            catch (Exception ex)
            {
            }
            finally
            {
                disconnect();
            }
            return dt;
        }
        public DataTable Getcategory(BAL_STOCK objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_PRODUCT";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", objBal.ACTION);
                cmd.Parameters.AddWithValue("CID", objBal.CID);

                cmd.Parameters.AddWithValue("CNAME", objBal.CNAME);


                da.Fill(dt);
            }
            catch (Exception ex)
            {
            }
            finally
            {
                disconnect();
            }
            return dt;
        }
    }
}