﻿using INMS.BAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace INMS.DAL
{
    public class DAL_R : Conection
    {
        string str = "";
        public string Register(BAL_R objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_REGISTER";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "INSERT");
                cmd.Parameters.AddWithValue("USERNAME", objBal.USERNAME);
                cmd.Parameters.AddWithValue("EMAIL", objBal.EMAIL);
                cmd.Parameters.AddWithValue("PASSWORD", objBal.PASSWORD);
                cmd.Parameters.AddWithValue("FNAME", objBal.FNAME);
                cmd.Parameters.AddWithValue("LNAME", objBal.LNAME);
                cmd.Parameters.AddWithValue("ADDRES", objBal.ADDRES);

                cmd.Parameters.Add("MSG", SqlDbType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                str = cmd.Parameters["MSG"].Value.ToString();
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            finally
            {
                disconnect();
            }
            return str;
        }
    }
}