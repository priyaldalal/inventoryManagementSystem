﻿using INMS.BAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace INMS.DAL
{
    public class DAL_CAT : Conection
    {
        string str = "";
        public string ManageUser(BAL_CAT objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_CATEGORY";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "INSERT");
                cmd.Parameters.AddWithValue("CNAME", objBal.CNAME);
                

                cmd.Parameters.Add("MSG", SqlDbType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                str = cmd.Parameters["MSG"].Value.ToString();
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            finally
            {
                disconnect();
            }
            return str;
        }
       

        public DataTable GETDETAIL(BAL_CAT objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_CATEGORY";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "SEL");
                cmd.Parameters.AddWithValue("CID", objBal.CID);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
            }
            finally
            {
                disconnect();
            }
            return dt;
        }



        public string UPDATEUSER(BAL_CAT objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_CATEGORY";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "UPDATE");
                cmd.Parameters.AddWithValue("CID", objBal.CID);
                cmd.Parameters.AddWithValue("CNAME", objBal.CNAME);
              
                cmd.Parameters.Add("MSG", SqlDbType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                str = cmd.Parameters["MSG"].Value.ToString();
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            finally
            {
                disconnect();
            }
            return str;
        }

       
        public DataTable GetALl(BAL_CAT objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_CATEGORY";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "SELALL");
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            finally
            {
                disconnect();
            }
            return dt;
        }
        public string Delete1(BAL_CAT objBal)
        {
            str = "";
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_CATEGORY";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "DELETE");
                cmd.Parameters.AddWithValue("CID", objBal.CID);

                cmd.Parameters.Add("MSG", SqlDbType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                str = cmd.Parameters["MSG"].Value.ToString();
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            finally
            {
                disconnect();
            }
            return str;
        }


        //BRAND

        public string BRANDADD(BAL_CAT objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_BRAND";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "INSERT");
                cmd.Parameters.AddWithValue("CATEGORY", objBal.CATEGORY);
                cmd.Parameters.AddWithValue("BNAME", objBal.BNAME);
                cmd.Parameters.AddWithValue("BDISCRIPTION", objBal.BDISCRIPTION);


                cmd.Parameters.Add("MSG", SqlDbType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                str = cmd.Parameters["MSG"].Value.ToString();
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            finally
            {
                disconnect();
            }
            return str;
        }


        public DataTable BRANDGETDETAIL(BAL_CAT objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_BRAND";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "SEL");
                cmd.Parameters.AddWithValue("BID", objBal.BID);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
            }
            finally
            {
                disconnect();
            }
            return dt;
        }



        public string UPDATEUSER1(BAL_CAT objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_BRAND";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "UPDATE");
                cmd.Parameters.AddWithValue("BID", objBal.BID);
                cmd.Parameters.AddWithValue("CATEGORY", objBal.CATEGORY);
                cmd.Parameters.AddWithValue("BNAME", objBal.BNAME);
                cmd.Parameters.AddWithValue("BDISCRIPTION", objBal.BDISCRIPTION);

                cmd.Parameters.Add("MSG", SqlDbType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                str = cmd.Parameters["MSG"].Value.ToString();
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            finally
            {
                disconnect();
            }
            return str;
        }

        public DataTable GETBRAND(BAL_CAT objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_BRAND";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "SELALL");
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            finally
            {
                disconnect();
            }
            return dt;
        }
         public string Delete(BAL_CAT objBal)
        {
            str = "";
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_BRAND";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "DELETE");
                cmd.Parameters.AddWithValue("BID", objBal.BID);

                cmd.Parameters.Add("MSG", SqlDbType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                str = cmd.Parameters["MSG"].Value.ToString();
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            finally
            {
                disconnect();
            }
            return str;
        }

         public DataTable Getcategory(BAL_CAT objBal)
         {
             try
             {
                 Connect();
                 cmd.Connection = con;
                 cmd.CommandText = "dbo.SP_PRODUCT";
                 cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("ACTION", objBal.ACTION);
                 cmd.Parameters.AddWithValue("CID", objBal.CID);

                 cmd.Parameters.AddWithValue("CNAME", objBal.CNAME);


                 da.Fill(dt);
             }
             catch (Exception ex)
             {
             }
             finally
             {
                 disconnect();
             }
             return dt;
         }
    
    }
}