﻿using INMS.BAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INMS.DAL
{
    public class DAL_FILE : Conection
    {
       string str = "";
        //public string MasterData(BAL_FILE objBal)
        //{
        //    try
        //    {
        //        Connect();
        //        cmd.Connection = con;
        //        cmd.CommandText = "dbo.SP_WH_INSPECTION_ENTRY";
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.Parameters.AddWithValue("ACTION", objBal.ACTION);
        //        cmd.Parameters.AddWithValue("WHID", objBal.WHID);
        //        cmd.Parameters.Add("MSG", SqlDbType.VarChar, 1000).Direction = ParameterDirection.Output;
        //        cmd.ExecuteNonQuery();
        //        str = cmd.Parameters["MSG"].Value.ToString();
        //    }
        //    catch (Exception ex)
        //    { }
        //    finally
        //    {
        //        disconnect();
        //    }
        //    return str;
        //}
        public string ManageEntry(BAL_FILE objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_UPLOAD";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", objBal.ACTION);


                cmd.Parameters.AddWithValue("DOCUMENTXML", objBal.DOCUMENTXML);

                
                cmd.Parameters.Add("MSG", SqlDbType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                str = cmd.Parameters["MSG"].Value.ToString();
                //objBal.EntryStatus = str;
                //objBal.CLRCODE = cmd.Parameters["CLRCODE"].Value.ToString();
            }
            catch (Exception ex)
            {
                str = "n";
            }
            finally
            {
                disconnect();
            }
            return str;
        }
        //public DataSet ManageData(BAL_FILE objBal)
        //{
        //    try
        //    {
        //        Connect();
        //        cmd.Connection = con;
        //        cmd.CommandText = "dbo.SP_WH_INSPECTION_ENTRY";
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.Parameters.AddWithValue("ACTION", objBal.ACTION);
        //        cmd.Parameters.AddWithValue("WHID", objBal.UPLOADID);
        //        cmd.Parameters.AddWithValue("SEARCHTEXT", objBal.SearchText);
        //        da.Fill(ds);
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    finally
        //    {
        //        disconnect();
        //    }
        //    return ds;
        //}
        public DataTable GetFileView(BAL_FILE objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_UPLOAD";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", objBal.ACTION);
                cmd.Parameters.AddWithValue("UPLOADID", objBal.UPLOADID);
                //cmd.Parameters.AddWithValue("USERID", objBal.UserID);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
            }
            finally
            {
                disconnect();
            }
            return dt;
        }



        public DataTable GetALl(BAL_FILE objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_UPLOAD";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "SELALL");
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            finally
            {
                disconnect();
            }
            return dt;
        }
        public DataTable GETDETAIL(BAL_FILE objBal)
        {
            try
            {
                Connect();
                cmd.Connection = con;
                cmd.CommandText = "dbo.SP_UPLOAD";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ACTION", "SEL");
                cmd.Parameters.AddWithValue("UPLOADID", objBal.UPLOADID);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
            }
            finally
            {
                disconnect();
            }
            return dt;
        }

    }
}