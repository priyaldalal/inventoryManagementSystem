﻿using INMS.BAL;
using INMS.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace INMS.USERCONTROL
{
    public partial class STOCK : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [System.Web.Services.WebMethod]
        public static string Save(int USERID, string CATEGORY, string PNAME, string BRAND, string QUALITY, string AVALIBALITY, int COST, string DATE)
        {
            string str = "";
            BAL_STOCK objBal = new BAL_STOCK();
            BLL_STOCK objBll = new BLL_STOCK();

            objBal.USERID = USERID;
            objBal.PNAME = PNAME;
            objBal.BRAND = BRAND;
            objBal.CATEGORY = CATEGORY;
            objBal.QUALITY = QUALITY;
            objBal.AVALIBALITY = AVALIBALITY;
            objBal.COST = COST;
            objBal.DATE = DATE;

            str = objBll.ManageUser(objBal);

            return str;
        }
        [System.Web.Services.WebMethod]
        public static string GetAll()
        {
            string str = "";
            BAL_STOCK objBal = new BAL_STOCK();
            BLL_STOCK objBll = new BLL_STOCK();

            DataTable dt = objBll.GetALl(objBal);

            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;
        }

        [System.Web.Services.WebMethod]
        public static string GETDETAIL(int STOCKID)
        {
            string str = "";
            BAL_STOCK objBal = new BAL_STOCK();
            BLL_STOCK objBll = new BLL_STOCK();

            objBal.STOCKID = STOCKID;
            DataTable dt = objBll.GETDETAIL(objBal);

            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;
        }

        [System.Web.Services.WebMethod]
        public static string UPDATEUSER(int USERID, int STOCKID, string QUALITY, string AVALIBALITY, int COST, string DATE)
        {
            string str = "";
            BAL_STOCK objBal = new BAL_STOCK();
            BLL_STOCK objBll = new BLL_STOCK();

            objBal.USERID = USERID;
            objBal.STOCKID = STOCKID;
            objBal.QUALITY = QUALITY;
            objBal.AVALIBALITY = AVALIBALITY;
            objBal.COST = COST;
            objBal.DATE = DATE;

            str = objBll.UPDATEUSER(objBal);

            return str;
        }
        [System.Web.Services.WebMethod]
        public static string DELETE(int STOCKID)
        {
            string str = "";
            BAL_STOCK objBal = new BAL_STOCK();
            BLL_STOCK objBll = new BLL_STOCK();
            objBal.STOCKID = STOCKID;

            str = objBll.Delete(objBal);

            return str;
        }
        [WebMethod]
        public static string GetPRODUCT()
        {
            string str = "";

            BAL_STOCK objBal = new BAL_STOCK();
            BLL_STOCK objBll = new BLL_STOCK();
            objBal.ACTION = "BINDPRODUCT";
            DataTable dt = objBll.GetPRODUCT(objBal);
            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;

        }
        public static string Getcategory()
        {
            string str = "";

            BAL_PRODUCT objBal = new BAL_PRODUCT();
            BLL_PRODUCT objBll = new BLL_PRODUCT();
            objBal.ACTION = "BINDCATEGORY";
            DataTable dt = objBll.Getcategory(objBal);
            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;

        }

        [WebMethod]
        public static string GetBRAND()
        {
            string str = "";

            BAL_PRODUCT objBal = new BAL_PRODUCT();
            BLL_PRODUCT objBll = new BLL_PRODUCT();
            objBal.ACTION = "BINDBRAND";
            DataTable dt = objBll.GetBRAND(objBal);
            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;

        }
    }
}