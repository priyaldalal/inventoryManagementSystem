﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;

namespace INMS
{
    public class clsCommon
    {
        public static DateTime ConvertToDateTime(string IO, string DateFormat = "dd-MM-yyyy")
        {
            if (IO == "" || IO == string.Empty)
            {
                DateFormat = "dd-MM-yyyy";
                IO = "01-01-1900";
            }
            DateTime OP;
            DateTime.TryParseExact(IO, DateFormat, null, DateTimeStyles.None, out OP);
            return OP;
        }

        internal static DateTime? ConvertToDateTime(DateTime CDATE)
        {
            throw new NotImplementedException();
        }
    }
}