﻿using INMS.BAL;
using INMS.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace INMS
{
    public partial class BRAND : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [System.Web.Services.WebMethod]
        public static string BRANDADD(string BNAME, string BDISCRIPTION)
        {
            string str = "";
            BAL_CAT objBal = new BAL_CAT();
            BLL_CAT objBll = new BLL_CAT();

            objBal.BNAME = BNAME;
            objBal.BDISCRIPTION = BDISCRIPTION;

            str = objBll.BRANDADD(objBal);

            return str;
        }
        

        [System.Web.Services.WebMethod]
        public static string BRANDGETDETAIL(int BID)
        {
            string str = "";
            BAL_CAT objBal = new BAL_CAT();
            BLL_CAT objBll = new BLL_CAT();

            objBal.BID = BID;
            DataTable dt = objBll.BRANDGETDETAIL(objBal);

            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;
        }

        [System.Web.Services.WebMethod]
        public static string GETBRAND()
        {
            string str = "";
            BAL_CAT objBal = new BAL_CAT();
            BLL_CAT objBll = new BLL_CAT();

            DataTable dt = objBll.GETBRAND(objBal);

            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;
        }
        [System.Web.Services.WebMethod]
        public static string UPDATEUSER1(int BID, string BNAME, string BDISCRIPTION)
        {
            string str = "";
            BAL_CAT objBal = new BAL_CAT();
            BLL_CAT objBll = new BLL_CAT();

            objBal.BID = BID;
            objBal.BNAME = BNAME;
            objBal.BDISCRIPTION = BDISCRIPTION;

            str = objBll.UPDATEUSER1(objBal);

            return str;
        }
        [System.Web.Services.WebMethod]
        public static string DELETE(int BID)
        {
            string str = "";
            BAL_CAT objBal = new BAL_CAT();
            BLL_CAT objBll = new BLL_CAT();
            objBal.BID = BID;

            str = objBll.Delete(objBal);

            return str;
        }
      
       
    }
}