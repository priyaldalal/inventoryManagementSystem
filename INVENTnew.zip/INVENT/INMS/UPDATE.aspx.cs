﻿using INMS.BAL;
using INMS.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace INMS
{
    public partial class UPDATE : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [System.Web.Services.WebMethod]
        public static string Save(string USERNAME, string EMAIL, string PASSWORD)
        {
            string str = "";
            BAL_USER objBal = new BAL_USER();
            BLL_USER objBll = new BLL_USER();

            objBal.USERNAME = USERNAME;
            objBal.EMAIL = EMAIL;
            objBal.PASSWORD = PASSWORD;
            str = objBll.ManageUser(objBal);

            return str;
        }
        [System.Web.Services.WebMethod]
        public static string GetAll()
        {
            string str = "";
            BAL_USER objBal = new BAL_USER();
            BLL_USER objBll = new BLL_USER();

            DataTable dt = objBll.GetALl(objBal);

            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;
        }

        [System.Web.Services.WebMethod]
        public static string GETDETAIL(int USERID)
        {
            string str = "";
            BAL_USER objBal = new BAL_USER();
            BLL_USER objBll = new BLL_USER();

            objBal.USERID = USERID;
            DataTable dt = objBll.GETDETAIL(objBal);

            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;
        }

        [System.Web.Services.WebMethod]
        public static string UPDATEUSER(int USERID, string USERNAME, string EMAIL, string PASSWORD)
        {
            string str = "";
            BAL_USER objBal = new BAL_USER();
            BLL_USER objBll = new BLL_USER();

            objBal.USERID = USERID;
            objBal.USERNAME = USERNAME;
            objBal.EMAIL = EMAIL;
            objBal.PASSWORD = PASSWORD;
            str = objBll.UPDATEUSER(objBal);

            return str;
        }
    }
}