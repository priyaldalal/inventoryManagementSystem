﻿using System;
using INMS.BAL;
using INMS.BLL;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;

using System.Xml;

namespace INMS
{
    public partial class ProductEntry : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [System.Web.Services.WebMethod]
        public static string Save(int USERID, string CATEGORY, string BRAND, string PNAME)
        {
            string str = "";
            BAL_P objBal = new BAL_P();
            BLL_P objBll = new BLL_P();

            objBal.USERID = USERID;
            objBal.PNAME = PNAME;
            objBal.CATEGORY = CATEGORY;   
            objBal.BRAND = BRAND;
           

            str = objBll.product(objBal);

            return str;
        }
        [System.Web.Services.WebMethod]
        public static string UPDATE(int USERID, int PID, string PNAME, string CATEGORY, string BRAND)
        {
            string str = "";
            BAL_P objBal = new BAL_P();
            BLL_P objBll = new BLL_P();
            objBal.USERID = USERID;
            objBal.PID = PID;
            objBal.PNAME = PNAME;
           
            objBal.CATEGORY = CATEGORY;
            objBal.BRAND = BRAND;
          

            str = objBll.UPDATE(objBal);


            return str;
        }

        [System.Web.Services.WebMethod]
        public static string DELETE(int PID)
        {
            string str = "";
            BAL_P objBal = new BAL_P();
            BLL_P objBll = new BLL_P();
            objBal.PID = PID;

            str = objBll.Delete(objBal);

            return str;
        }
        [System.Web.Services.WebMethod]
        public static string GetAll()
        {
            string str = "";
            BAL_P objBal = new BAL_P();
            BLL_P objBll = new BLL_P();

            DataTable dt = objBll.GetALl(objBal);

            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;
        }
        [System.Web.Services.WebMethod]
        public static string GETDETAIL(int PID)
        {
            string str = "";
            BAL_P objBal = new BAL_P();
            BLL_P objBll = new BLL_P();
            objBal.PID = PID;

            DataTable dt = objBll.GETDETAIL(objBal);

            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;
        }
        
    }
}