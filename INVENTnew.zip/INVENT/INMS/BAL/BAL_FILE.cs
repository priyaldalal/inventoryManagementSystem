﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace INMS.BAL
{
    public class BAL_FILE
    {
        public string ACTION { get; set; }
        public string DOCUMENTXML { get; set; }
        public string UPLOADID { get; set; }
        
    }
}