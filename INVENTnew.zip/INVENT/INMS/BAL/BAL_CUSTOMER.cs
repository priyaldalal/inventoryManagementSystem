﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace INMS.BAL
{
    public class BAL_CUSTOMER
    {
        public string ACTION { get; set; }
        public int CID { get; set; }
        public int USERID { get; set; }
        public int INVOICENO { get; set; }
        public string CNAME { get; set; }
        public string CEMAIL { get; set; }
        public string CNUMBER { get; set; }
        public DateTime ENTRYDATE { get; set; }
        public string CDATE { get; set; }
    }
}