﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace INMS.BAL
{
    public class BAL_USER
    {
        public int USERID { get; set; }
        public int UPDATEID { get; set; }
        public string USERNAME { get; set; }
        public string EMAIL { get; set; }
        public string PASSWORD { get; set; }

        public string FNAME { get; set; }
        public string LNAME { get; set; }
        public int Contect { get; set; }
        public string ADD { get; set; }
        public string ADDRES { get; set; }
        public string ACTION { get; set; }
        public string DOCUMENTXML { get; set; }
        public string UPLOADID { get; set; }
        public string FileName { get; set; }
        public string FileExt { get; set; }
        public string FileUpload { get; set; }
    }
}