﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace INMS.BAL
{
    public class BAL_R
    {
         public int USERID { get; set; }
        public string USERNAME { get; set; }
        public string EMAIL { get; set; }
        public string PASSWORD { get; set; }

        public string FNAME { get; set; }
        public string LNAME { get; set; }
        public string ADDRES { get; set; }
    }
    
}