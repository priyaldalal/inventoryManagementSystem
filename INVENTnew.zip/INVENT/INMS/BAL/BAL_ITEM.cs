﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace INMS.BAL
{
    public class BAL_ITEM
    {
        public string ACTION { get; set; }
        //public string DOCUMENTXML { get; set; }
        public string ITEMDTLXML { get; set; }
        public string ITEMID { get; set; }
        public string USERID { get; set; }
        public int CID { get; set; }
        public string INVNO { get; set; }
        public string CNAME { get; set; }
        public DateTime? CDATE { get; set; }
        public DateTime CURRENTDATE { get; set; }






    }
}