﻿using INMS.BAL;
using INMS.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace INMS
{
    public partial class REGISTER : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [System.Web.Services.WebMethod]
        public static string Save(string USERNAME, string EMAIL, string PASSWORD,string FNAME,string LNAME)
        {
            string str = "";
            BAL_USER objBal = new BAL_USER();
            BLL_USER objBll = new BLL_USER();

            objBal.USERNAME = USERNAME;
            objBal.EMAIL = EMAIL;
            objBal.PASSWORD = PASSWORD;
            objBal.FNAME = FNAME;
            objBal.LNAME = LNAME;
            str = objBll.ManageUser(objBal);

            return str;
        }
        [System.Web.Services.WebMethod]
        public static string GetAll()
        {
            string str = "";
            BAL_USER objBal = new BAL_USER();
            BLL_USER objBll = new BLL_USER();

            DataTable dt = objBll.GetALl(objBal);

            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;
        }

        [System.Web.Services.WebMethod]
        public static string GETDETAIL(int USERID)
        {
            string str = "";
            BAL_USER objBal = new BAL_USER();
            BLL_USER objBll = new BLL_USER();

            objBal.USERID = USERID;
            DataTable dt = objBll.GETDETAIL(objBal);
            if (dt.Rows[0]["DOCUMENT"].ToString() != "")
            {
                Byte[] bytes = (Byte[])dt.Rows[0]["DOCUMENT"];
                string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                base64String = "data:image/png;base64," + base64String;
                dt.Rows[0]["DOCFILE"] = base64String;
            }
            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;
        }

        [System.Web.Services.WebMethod]
        public static string UPDATEUSER(int USERID, string USERNAME, string EMAIL, string PASSWORD, string FNAME, string LNAME, string IMGNAME, string IMGUPLOAD, string IMGEXT)
        {
            string str = "";
            BAL_USER objBal = new BAL_USER();
            BLL_USER objBll = new BLL_USER();

            objBal.USERID = USERID;
            objBal.USERNAME = USERNAME;
            objBal.EMAIL = EMAIL;
            objBal.PASSWORD = PASSWORD;
            objBal.FNAME = FNAME;
            objBal.LNAME = LNAME;
            objBal.FileUpload = IMGUPLOAD;
            objBal.FileName = IMGNAME;
            objBal.FileExt = IMGEXT;
            str = objBll.UPDATEUSER(objBal);

            return str;
        }


        [System.Web.Services.WebMethod]
        public static string UPDATE(int USERID, string USERNAME, string EMAIL, string PASSWORD, string FNAME, string LNAME)
        {
            string str = "";
            BAL_USER objBal = new BAL_USER();
            BLL_USER objBll = new BLL_USER();

            objBal.USERID = USERID;
            objBal.USERNAME = USERNAME;
            objBal.EMAIL = EMAIL;
            objBal.PASSWORD = PASSWORD;
            objBal.FNAME = FNAME;
            objBal.LNAME = LNAME;
           
            str = objBll.UPDATE(objBal);

            return str;
        }

        [System.Web.Services.WebMethod]
        public static string DELETE(int USERID)
        {
            string str = "";
            BAL_USER ObjBal = new BAL_USER();
            BLL_USER ObjBll = new BLL_USER();
            ObjBal.USERID = USERID;

            str = ObjBll.Delete(ObjBal);

            return str;
        }
    }
}