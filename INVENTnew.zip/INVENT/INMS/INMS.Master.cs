﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace INMS
{
    public partial class INMS : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["PRIYALUSERID"] == null || HttpContext.Current.Session["PRIYALUSERNAME"].ToString() == "" || HttpContext.Current.Session["PRIYALUSERFNAME"].ToString() == "" || HttpContext.Current.Session["PRIYALUSERLNMAE"].ToString() == "")
            {
                Response.Redirect("Login.aspx");
            }
        }
    }
}