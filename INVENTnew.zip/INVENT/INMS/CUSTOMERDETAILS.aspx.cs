﻿using INMS.BAL;
using INMS.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace INMS
{
    public partial class CUSTOMERDETAILS : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
       

        [System.Web.Services.WebMethod]
        public static string Save(int USERID,  string CNAME, string CEMAIL, string CNUMBER)
        {
            string str = "";
            //TimeZoneInfo destinationTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            //DateTime ENTRYDATE = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, destinationTimeZone);

            BAL_CUSTOMER objBal = new BAL_CUSTOMER();
            BLL_CUSTOMER objBll = new BLL_CUSTOMER();
          
            objBal.USERID = USERID;
            objBal.CNAME = CNAME;
            //objBal.INVOICENO = INVOICENO;
            objBal.CEMAIL = CEMAIL;
            objBal.CNUMBER = CNUMBER;
            //objBal.CDATE = CDATE;
            
            //objBal.ENTRYDATE = ENTRYDATE;

            str = objBll.Savedata(objBal);

            return str;
        }
        [System.Web.Services.WebMethod]
        public static string GetAll()
        {
            string str = "";
            BAL_CUSTOMER objBal = new BAL_CUSTOMER();
            BLL_CUSTOMER objBll = new BLL_CUSTOMER();

            DataTable dt = objBll.GetALl(objBal);

            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;
        }

        [System.Web.Services.WebMethod]
        public static string GETDETAIL(int CID)
        {
            string str = "";
            BAL_CUSTOMER objBal = new BAL_CUSTOMER();
            BLL_CUSTOMER objBll = new BLL_CUSTOMER();

            objBal.CID = CID;
            DataTable dt = objBll.GETDETAIL(objBal);

            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;
        }
        [System.Web.Services.WebMethod]
        public static string UPDATE(int USERID, int CID, string CNAME, string CEMAIL, string CNUMBER)
        {
            string str = "";
            BAL_CUSTOMER objBal = new BAL_CUSTOMER();
            BLL_CUSTOMER objBll = new BLL_CUSTOMER();
            //TimeZoneInfo destinationTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            //DateTime ENTRYDATE = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, destinationTimeZone);

            objBal.USERID = USERID;
            objBal.CID = CID;
            objBal.CNAME = CNAME;
            objBal.CEMAIL = CEMAIL;
            objBal.CNUMBER = CNUMBER;
           

            str = objBll.UPDATE(objBal);


            return str;
        }

        [System.Web.Services.WebMethod]
        public static string DELETE(int CID)
        {
            string str = "";
            BAL_CUSTOMER objBal = new BAL_CUSTOMER();
            BLL_CUSTOMER objBll = new BLL_CUSTOMER();
            objBal.CID = CID;

            str = objBll.Delete(objBal);

            return str;
        }
    
    }
}