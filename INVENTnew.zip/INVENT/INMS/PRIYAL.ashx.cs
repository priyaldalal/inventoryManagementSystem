﻿using INMS.BAL;
using INMS.BLL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;


namespace INMS
{
    /// <summary>
    /// Summary description for PRIYAL
    /// </summary>
    public class PRIYAL : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            string ID = context.Request.QueryString["ID"];
            byte[] bytes;

            BAL_FILE objBal = new BAL_FILE();
            BLL_FILE objBll = new BLL_FILE();
            objBal.ACTION = "GETVIEWFILE";
            objBal.UPLOADID = ID;

            DataTable dt = objBll.GetFileView(objBal);
            string fileExt = "";
            if (dt.Rows.Count > 0)
            {
                bytes = (byte[])dt.Rows[0]["DOCUMENT"];
                fileExt = dt.Rows[0]["EXTENSION"].ToString();

                context.Response.Buffer = true;
                context.Response.Charset = "";

                //if (download == "Y")
                //    context.Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileName);

                context.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                if (fileExt.ToLower() == "pdf" || fileExt.ToLower() == "xlsx")
                {
                    context.Response.ContentType = "application/" + fileExt.ToLower() + "";
                }
                else
                {
                    context.Response.ContentType = "image/" + fileExt.ToLower() + "";
                }

                context.Response.BinaryWrite(bytes);
                context.Response.Flush();
                context.Response.End();
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}