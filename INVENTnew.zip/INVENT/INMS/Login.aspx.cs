﻿using INMS.BAL;
using INMS.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace INMS
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [WebMethod(EnableSession = true)]
        public static string UserLogin(string USERNAME, string PASSWORD)
        {
            string str = "";
            try
            {
                BAL_USER objBal = new BAL_USER();
                BLL_USER objBll = new BLL_USER();

                objBal.USERNAME = USERNAME;
                objBal.PASSWORD = PASSWORD;

                DataTable dtLogin = objBll.GetData(objBal);
                if (dtLogin.Rows.Count > 0)
                {
                    string pass = dtLogin.Rows[0]["PASSWORD"].ToString();
                    if (pass == PASSWORD)
                    {
                        HttpContext.Current.Session["PRIYALUSERID"] = dtLogin.Rows[0]["USERID"].ToString(); ;
                        HttpContext.Current.Session["PRIYALUSERNAME"] = dtLogin.Rows[0]["USERNAME"].ToString();
                        HttpContext.Current.Session["PRIYALUSEREMAIL"] = dtLogin.Rows[0]["EMAIL"].ToString();
                        HttpContext.Current.Session["PRIYALUSERFNAME"] = dtLogin.Rows[0]["FNAME"].ToString();
                        HttpContext.Current.Session["PRIYALUSERLNMAE"] = dtLogin.Rows[0]["LNAME"].ToString(); 
                        str = "y";
                    }
                    else
                    {
                        str = "P/Incorrect password..!";
                    }
                }
                else
                {
                    str = "U/Invalid username or credentials..!";
                }
            }
            catch (Exception ex)
            {
                str = ex.Message.ToString();
            }
            return str;
        }
        [WebMethod]
        public static string Logout()
        {
            HttpContext.Current.Session["PRIYALUSERID"] = null;
            HttpContext.Current.Session["PRIYALUSERNAME"] = null;
            HttpContext.Current.Session.Abandon();
            return "y";
        }
    }
}