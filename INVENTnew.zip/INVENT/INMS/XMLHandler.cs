﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Xml;
using System.Xml.Linq;

namespace INMS
{
    public class XMLHandler
    {
        public static string ConvertXMLtoString(XmlDocument xmldoc)
        {
          string text = string.Empty;
            try
            {
                using (StringWriter writer = new StringWriter())
                {
                    using (XmlWriter writer2 = XmlWriter.Create(writer))
                    {
                        xmldoc.WriteTo(writer2);
                        writer2.Flush();
                        text = writer.GetStringBuilder().ToString();
                        return XElement.Parse(text).ToString();
                    }
                }
            }
            catch (Exception)
            {
                text = string.Empty;
            }
            return text;
        }

        public static void CreateXMLEle(ref XmlDocument xmlDoc, ref XmlElement parentNode, string eleName, string eleVal)
        {
            if (eleName != "")
            {
                XmlElement newChild = xmlDoc.CreateElement(eleName);
                XmlText text = xmlDoc.CreateTextNode(eleVal);
                newChild.AppendChild(text);
                parentNode.AppendChild(newChild);
            }
        }


    }
}